/**
 * KRANTIVEER BANDA — Google Apps Script registration backend
 * Player registration: ₹500 manual UPI/PhonePe payment + UTR verification
 * Franchise registration: no payment collected on this form.
 *
 * Required Script configuration:
 * - SPREADSHEET_ID is set below.
 * - Deploy as Web App: Execute as Me / Who has access: Anyone.
 */
const SPREADSHEET_ID="1na16FW2NUHXd35_e9-1q-ca1lFjRIneVBGsyQ8k-BJg";
const SHEET_NAME="Players";
const FRANCHISE_SHEET_NAME="Franchises";
const DRIVE_FOLDER_NAME="Krantiveer Banda Player Photos";
const PLAYER_FEE="₹500";

function doGet(){
  return json_({ok:true,message:"Krantiveer Banda registration backend is live."});
}

function doPost(e){
  try{
    const body=e?.postData?.contents||"";
    if(!body)throw new Error("No request body received.");
    const data=JSON.parse(body);

    if(data.formType==="franchise") return handleFranchise_(data);
    return handlePlayer_(data);
  }catch(err){
    return json_({ok:false,message:String(err.message||err)});
  }
}

function handlePlayer_(data){
  validatePlayer_(data);

  const ss=SpreadsheetApp.openById(SPREADSHEET_ID);
  const sh=getPlayerSheet_(ss);
  const id=makeId_("PLY");
  const folder=getFolder_();

  const photo=save_(folder,data.playerPhotoBase64,data.playerPhotoName,data.playerPhotoMimeType);
  const front=save_(folder,data.idFrontBase64,data.idFrontName,data.idFrontMimeType);
  const back=save_(folder,data.idBackBase64,data.idBackName,data.idBackMimeType);

  const row=[
    new Date(),id,
    data.fullName||"",
    data.fatherName||"",
    data.dob||"",
    data.idProofType||"",
    data.idProofNumber||"",
    data.district||"",
    data.mobile||"",
    data.whatsapp||"",
    data.email||"",
    data.address||"",
    data.role||"",
    data.batting||"",
    data.bowlingArm||"",
    data.bowling||"",
    data.jersey||"",
    data.experience||"",
    data.tshirtSize||"",
    data.lowerSize||"",
    data.tshirtName||"",
    data.tshirtNumber||"",
    photo,front,back,
    "UTR Submitted - Verification Pending"
  ];

  // Preserve older Razorpay columns if this Players sheet already has them,
  // then add the new UTR field at the end.
  const lastCol=sh.getLastColumn();
  if(lastCol>=30){
    while(row.length<29) row.push("");
    row.push(String(data.utr||""));
  }else{
    row.push(String(data.utr||""));
  }

  sh.appendRow(row);

  return json_({
    ok:true,
    registrationId:id,
    message:"Registration submitted. UTR is pending payment verification."
  });
}

function handleFranchise_(data){
  validateFranchise_(data);

  const ss=SpreadsheetApp.openById(SPREADSHEET_ID);
  const sh=getFranchiseSheet_(ss);
  const id=makeId_("FRN");
  const folder=getFolder_();

  const front=save_(folder,data.idFrontBase64,data.idFrontName,data.idFrontMimeType);
  const back=save_(folder,data.idBackBase64,data.idBackName,data.idBackMimeType);

  sh.appendRow([
    new Date(),id,
    data.franchiseName||"",
    data.ownerName||"",
    data.mobile||"",
    data.whatsapp||"",
    data.email||"",
    data.district||"",
    data.address||"",
    data.idProofType||"",
    data.idProofNumber||"",
    data.experience||"",
    front,back,
    "Submitted"
  ]);

  return json_({ok:true,registrationId:id});
}

function validatePlayer_(d){
  [
    "fullName","fatherName","dob","idProofType","idProofNumber",
    "district","address","mobile","role","batting","bowlingArm",
    "tshirtSize","lowerSize","tshirtName","tshirtNumber",
    "utr","playerPhotoBase64","idFrontBase64","idBackBase64"
  ].forEach(k=>{
    if(!d[k])throw new Error("Missing required field: "+k);
  });

  if(!/^\d{10}$/.test(String(d.mobile))){
    throw new Error("Mobile number must be 10 digits.");
  }

  if(d.whatsapp && !/^\d{10}$/.test(String(d.whatsapp))){
    throw new Error("WhatsApp number must be 10 digits.");
  }

  if(d.bowling && !["Medium Fast","Spin"].includes(String(d.bowling))){
    throw new Error("Invalid bowling style.");
  }

  if(!/^[A-Za-z0-9][A-Za-z0-9 ._\/-]{5,49}$/.test(String(d.utr).trim())){
    throw new Error("Invalid UTR / transaction ID.");
  }
}

function validateFranchise_(d){
  [
    "franchiseName","ownerName","mobile","district","address",
    "idProofType","idProofNumber","idFrontBase64","idBackBase64"
  ].forEach(k=>{
    if(!d[k])throw new Error("Missing required field: "+k);
  });

  if(!/^\d{10}$/.test(String(d.mobile))){
    throw new Error("Mobile number must be 10 digits.");
  }

  if(d.whatsapp && !/^\d{10}$/.test(String(d.whatsapp))){
    throw new Error("WhatsApp number must be 10 digits.");
  }
}

function getPlayerSheet_(ss){
  let s=ss.getSheetByName(SHEET_NAME);
  if(!s)s=ss.insertSheet(SHEET_NAME);

  if(s.getLastRow()===0){
    s.appendRow([
      "Timestamp","Registration ID","Player Name","Father's Name",
      "Date of Birth","ID Proof Type","ID Proof Number","District",
      "Mobile","WhatsApp","Email","Address","Player Type",
      "Batting Style","Bowling Arm","Bowling Style","Jersey Number",
      "Experience","T-Shirt Size","Lower Size","Name on T-Shirt",
      "T-Shirt Back Number","Player Photo URL","ID Front URL",
      "ID Back URL","Payment Status","UTR / Transaction ID"
    ]);
    s.setFrozenRows(1);
    s.getRange(1,1,1,s.getLastColumn()).setFontWeight("bold");
  }else{
    const headers=s.getRange(1,1,1,s.getLastColumn()).getValues()[0];
    if(!headers.includes("UTR / Transaction ID")){
      s.getRange(1,s.getLastColumn()+1).setValue("UTR / Transaction ID");
      s.getRange(1,1,1,s.getLastColumn()).setFontWeight("bold");
    }
  }

  return s;
}

function getFranchiseSheet_(ss){
  let s=ss.getSheetByName(FRANCHISE_SHEET_NAME);
  if(!s)s=ss.insertSheet(FRANCHISE_SHEET_NAME);

  if(s.getLastRow()===0){
    s.appendRow([
      "Timestamp","Registration ID","Franchise Name",
      "Owner / Representative","Mobile","WhatsApp","Email",
      "District / City","Address","ID Proof Type","ID Proof Number",
      "Experience","ID Front URL","ID Back URL","Status"
    ]);
    s.setFrozenRows(1);
    s.getRange(1,1,1,s.getLastColumn()).setFontWeight("bold");
  }

  return s;
}

function getFolder_(){
  const f=DriveApp.getFoldersByName(DRIVE_FOLDER_NAME);
  return f.hasNext()?f.next():DriveApp.createFolder(DRIVE_FOLDER_NAME);
}

function save_(folder,b64,name,mime){
  const blob=Utilities.newBlob(
    Utilities.base64Decode(b64),
    mime||MimeType.JPEG,
    name||("upload-"+Date.now())
  );
  return folder.createFile(blob).getUrl();
}

function makeId_(prefix){
  return "KVB-"+prefix+"-"+
    Utilities.formatDate(new Date(),Session.getScriptTimeZone(),"yyyyMMddHHmmss")+
    "-"+Math.floor(100+Math.random()*900);
}

function json_(o){
  return ContentService
    .createTextOutput(JSON.stringify(o))
    .setMimeType(ContentService.MimeType.JSON);
}
