/**
 * KRANTIVEER CRICKET LEAGUE — BANDA T10, SEASON 4
 * ------------------------------------------------
 * Run this ONCE from script.google.com to auto-create:
 *   1. A Google Sheet ("Krantiveer Banda T10 - Season 4 Registrations")
 *   2. A "Player Registration" Google Form  → writes to sheet "Player Registrations"
 *   3. A "Franchise Registration" Google Form → writes to sheet "Franchise Registrations"
 *
 * HOW TO USE
 *   1. Go to https://script.new  (this opens a blank Apps Script project)
 *   2. Delete the sample code and paste this whole file in.
 *   3. Click "Run" ▶ on the function dropdown → choose createKrantiveerForms → Run.
 *   4. The first run will ask you to authorize the script with your Google account — allow it.
 *   5. Open "Executions" (left sidebar) or View → Logs (Ctrl+Enter) to see the two form links.
 *   6. Copy the "fill" links into index.html (PLAYER_FORM_URL / FRANCHISE_FORM_URL).
 *   7. Open the generated Spreadsheet — a "Form Links" sheet has every URL saved for you too.
 *
 * IMPORTANT — FILE UPLOAD QUESTIONS MUST BE ADDED BY HAND
 *   Google does not allow "File upload" questions to be created through Apps Script
 *   (the FormApp service has no addFileUploadItem method) or through the Forms REST API —
 *   this question type can only be added from the Forms UI itself. This script builds
 *   every other question automatically and leaves a clearly labelled placeholder section
 *   exactly where each file-upload question belongs. After running the script, open each
 *   form's EDIT link (printed in the log / "Form Links" sheet) and add these questions by
 *   hand — it takes about 2 minutes total:
 *
 *   PLAYER FORM — inside "Documents & Payment" section, right after the "Photo & ID Uploads"
 *   header:
 *     • "Photograph for Auction"  → File upload, required, allow Images, max 1 file
 *     • "ID Card — Front"         → File upload, required, allow Images + PDF, max 1 file
 *     • "ID Card — Back"          → File upload, required, allow Images + PDF, max 1 file
 *
 *   FRANCHISE FORM — right after the "ID Proof Uploads" header:
 *     • "ID Proof — Front"        → File upload, required, allow Images + PDF, max 1 file
 *     • "ID Proof — Back"         → File upload, required, allow Images + PDF, max 1 file
 *
 *   To add one: open the form in Edit mode → click the "+" (Add question) button in the
 *   floating toolbar at the position you want it → click the question-type dropdown
 *   (defaults to "Multiple choice") → choose "File upload" → set the title exactly as
 *   above → toggle "Required" on → click the allowed file types you want.
 *
 *   Uploaded files land in a Drive folder Forms creates automatically inside the form
 *   owner's Google Drive (named after the form, e.g. "Krantiveer Banda T10 — Player
 *   Registration (Season 4) (File responses)").
 */

function createKrantiveerForms() {
  const ss = SpreadsheetApp.create('Krantiveer Banda T10 - Season 4 Registrations');
  const ssId = ss.getId();

  const playerForm = buildPlayerForm_(ssId);
  const franchiseForm = buildFranchiseForm_(ssId);

  // Rename the auto-created response sheets so they're easy to find.
  Utilities.sleep(1500); // give Forms a moment to attach the response sheets
  renameResponseSheet_(ss, 'Player Registrations');
  renameResponseSheet_(ss, 'Franchise Registrations');

  // Remove the blank default sheet Google creates with every new Spreadsheet.
  const defaultSheet = ss.getSheetByName('Sheet1');
  if (defaultSheet && ss.getSheets().length > 1) ss.deleteSheet(defaultSheet);

  const playerFillUrl = playerForm.getPublishedUrl();
  const franchiseFillUrl = franchiseForm.getPublishedUrl();

  // Save a human-readable summary sheet inside the same spreadsheet.
  const info = ss.insertSheet('Form Links');
  info.getRange(1, 1, 8, 2).setValues([
    ['Item', 'Link / Note'],
    ['Spreadsheet (all responses)', ss.getUrl()],
    ['Player Registration Form — SHARE this link on the website', playerFillUrl],
    ['Player Registration Form — EDIT to add file-upload questions', playerForm.getEditUrl()],
    ['Franchise Registration Form — SHARE this link on the website', franchiseFillUrl],
    ['Franchise Registration Form — EDIT to add file-upload questions', franchiseForm.getEditUrl()],
    ['STILL TO DO', 'Open each EDIT link above and manually add the File upload questions — see the comment block at the top of CreateForms.gs for the exact list.'],
    ['', '']
  ]);
  info.setColumnWidth(1, 420);
  info.setColumnWidth(2, 520);
  info.getRange(1, 1, 1, 2).setFontWeight('bold');
  info.getRange(7, 1, 1, 2).setFontWeight('bold').setBackground('#fff3cd');
  ss.setActiveSheet(info);
  ss.moveActiveSheet(1);

  // Keep the form IDs so you can re-print the links later without re-running everything.
  const props = PropertiesService.getScriptProperties();
  props.setProperty('PLAYER_FORM_ID', playerForm.getId());
  props.setProperty('FRANCHISE_FORM_ID', franchiseForm.getId());
  props.setProperty('SPREADSHEET_ID', ssId);

  Logger.log('=================================================');
  Logger.log('SPREADSHEET (all responses): ' + ss.getUrl());
  Logger.log('PLAYER FORM (share this):    ' + playerFillUrl);
  Logger.log('PLAYER FORM (edit):          ' + playerForm.getEditUrl());
  Logger.log('FRANCHISE FORM (share this): ' + franchiseFillUrl);
  Logger.log('FRANCHISE FORM (edit):       ' + franchiseForm.getEditUrl());
  Logger.log('=================================================');
  Logger.log('NEXT STEP (manual, ~2 min): open each EDIT link above and add the');
  Logger.log('File upload questions listed in the comment block at the top of this file.');
  Logger.log('THEN paste the two "share this" links into index.html as');
  Logger.log('PLAYER_FORM_URL and FRANCHISE_FORM_URL.');
}

/** Re-run any time later to print the saved links again without recreating forms. */
function printSavedFormLinks() {
  const props = PropertiesService.getScriptProperties();
  const playerId = props.getProperty('PLAYER_FORM_ID');
  const franchiseId = props.getProperty('FRANCHISE_FORM_ID');
  const ssId = props.getProperty('SPREADSHEET_ID');
  if (!playerId || !franchiseId) {
    Logger.log('No saved forms found — run createKrantiveerForms() first.');
    return;
  }
  const playerForm = FormApp.openById(playerId);
  const franchiseForm = FormApp.openById(franchiseId);
  Logger.log('SPREADSHEET: ' + SpreadsheetApp.openById(ssId).getUrl());
  Logger.log('PLAYER FORM (share this): ' + playerForm.getPublishedUrl());
  Logger.log('PLAYER FORM (edit):       ' + playerForm.getEditUrl());
  Logger.log('FRANCHISE FORM (share this): ' + franchiseForm.getPublishedUrl());
  Logger.log('FRANCHISE FORM (edit):       ' + franchiseForm.getEditUrl());
}

function renameResponseSheet_(ss, newName) {
  try {
    const sheets = ss.getSheets();
    for (let i = 0; i < sheets.length; i++) {
      const name = sheets[i].getName();
      if (name.indexOf('Form Responses') === 0) {
        sheets[i].setName(newName);
        return;
      }
    }
  } catch (e) {
    Logger.log('Could not rename a response sheet to ' + newName + ': ' + e);
  }
}

function buildPlayerForm_(spreadsheetId) {
  const form = FormApp.create('Krantiveer Banda T10 — Player Registration (Season 4)');
  form.setDescription(
    'Official player registration for Krantiveer Cricket League — Banda T10, Season 4 (2026). ' +
    'Registration fee: ₹500 via UPI / PhonePe QR (shown on the tournament website). ' +
    'Please pay first and keep your UTR / Transaction ID ready before you start this form.'
  );
  form.setCollectEmail(false);
  form.setProgressBar(true);
  form.setShowLinkToRespondAgain(true);
  form.setConfirmationMessage(
    'Thank you! Your player registration has been received. The tournament team will verify ' +
    'your payment and contact you if anything else is needed.'
  );
  form.setDestination(FormApp.DestinationType.SPREADSHEET, spreadsheetId);

  // ---- Section 1: Player Details ----
  form.addSectionHeaderItem()
    .setTitle('Player Details')
    .setHelpText('Personal and identity information');

  form.addTextItem().setTitle('Player Name').setRequired(true);
  form.addTextItem().setTitle("Father's Name").setRequired(true);
  form.addDateItem().setTitle('Date of Birth').setRequired(true);

  form.addMultipleChoiceItem()
    .setTitle('ID Proof Type')
    .setChoiceValues(['Aadhaar', 'Driving Licence', 'Voter ID', 'Passport', 'Bank Passbook'])
    .setRequired(true);

  form.addTextItem().setTitle('ID Proof Number').setRequired(true);

  form.addMultipleChoiceItem()
    .setTitle('Player District')
    .setChoiceValues(['Banda', 'Hamirpur', 'Chitrakoot', 'Mahoba', 'Other'])
    .setRequired(true);

  form.addParagraphTextItem().setTitle('Address').setRequired(true);

  form.addTextItem().setTitle('Mobile Number').setRequired(true)
    .setValidation(FormApp.createTextValidation()
      .requireTextMatchesPattern('^[0-9]{10}$')
      .setHelpText('Enter a valid 10-digit mobile number.')
      .build());

  form.addTextItem().setTitle('WhatsApp Number (optional)');

  form.addTextItem().setTitle('Email (optional)')
    .setValidation(FormApp.createTextValidation().requireTextIsEmail().build());

  // ---- Section 2: Cricket Profile ----
  form.addPageBreakItem()
    .setTitle('Cricket Profile')
    .setHelpText('Tell us how you play');

  form.addMultipleChoiceItem()
    .setTitle('Player Type')
    .setChoiceValues(['Bowler', 'Batsman', 'Batting All-rounder', 'Bowling All-rounder', 'Wicketkeeper'])
    .setRequired(true);

  form.addMultipleChoiceItem()
    .setTitle('Batting Style')
    .setChoiceValues(['Left Hand', 'Right Hand'])
    .setRequired(true);

  form.addMultipleChoiceItem()
    .setTitle('Bowling Arm')
    .setChoiceValues(['Left Hand', 'Right Hand', 'Does not bowl'])
    .setRequired(true);

  form.addMultipleChoiceItem()
    .setTitle('Bowling Style (optional)')
    .setChoiceValues(['Medium Fast', 'Spin'])
    .setRequired(false);

  form.addTextItem().setTitle('Jersey Number Preference (0–99, optional)')
    .setValidation(FormApp.createTextValidation().requireNumberBetween(0, 99).build());

  form.addParagraphTextItem().setTitle('Previous Cricket Experience (optional)');

  // ---- Section 3: T-Shirt Details ----
  form.addPageBreakItem()
    .setTitle('T-Shirt Details')
    .setHelpText('Information required for tournament kit');

  const sizes = ['XS', 'S', 'M', 'L', 'XL', 'XXL', '3XL', '4XL'];
  form.addListItem().setTitle('T-Shirt Size').setChoiceValues(sizes).setRequired(true);
  form.addListItem().setTitle('Lower Size').setChoiceValues(sizes).setRequired(true);

  form.addTextItem().setTitle('Name on T-Shirt (max 20 characters)').setRequired(true)
    .setValidation(FormApp.createTextValidation().requireTextLengthLessThanOrEqualTo(20).build());

  form.addTextItem().setTitle('T-Shirt Back Number (0–99)').setRequired(true)
    .setValidation(FormApp.createTextValidation().requireNumberBetween(0, 99).build());

  // ---- Section 4: Documents & Payment ----
  form.addPageBreakItem()
    .setTitle('Documents & Payment')
    .setHelpText('Upload your files and confirm payment. File uploads require you to be signed in with a Google account.');

  form.addSectionHeaderItem()
    .setTitle('Photo & ID Uploads')
    .setHelpText(
      'MANUAL SETUP NEEDED: right after this header, add three "File upload" questions ' +
      '(Google requires these to be added by hand in the Forms editor — see the comment ' +
      'at the top of CreateForms.gs for exact settings): ' +
      '"Photograph for Auction" (required, Images, max 1 file), ' +
      '"ID Card — Front" (required, Images + PDF, max 1 file), ' +
      '"ID Card — Back" (required, Images + PDF, max 1 file).'
    );

  form.addSectionHeaderItem()
    .setTitle('Registration Fee: ₹500')
    .setHelpText('Scan the PhonePe / UPI QR shown on the website, pay ₹500, then enter your UTR / Transaction ID below.');

  form.addTextItem().setTitle('UTR / Transaction ID').setRequired(true)
    .setValidation(FormApp.createTextValidation()
      .requireTextLengthGreaterThanOrEqualTo(6)
      .setHelpText('Use the UTR / transaction number from your UPI payment receipt.')
      .build());

  form.addCheckboxItem()
    .setTitle('Declaration')
    .setChoiceValues([
      'I confirm that the information provided is true and accurate to the best of my knowledge.',
      'I understand that false or misleading information may result in cancellation of my registration.'
    ])
    .setRequired(true);

  return form;
}

function buildFranchiseForm_(spreadsheetId) {
  const form = FormApp.create('Krantiveer Banda T10 — Franchise Registration (Season 4)');
  form.setDescription(
    'Franchise / team ownership enquiry for Krantiveer Cricket League — Banda T10, Season 4 (2026).'
  );
  form.setCollectEmail(false);
  form.setProgressBar(true);
  form.setShowLinkToRespondAgain(true);
  form.setConfirmationMessage(
    'Thank you! Your franchise details have been submitted. Our tournament team will contact ' +
    'you for the next steps.'
  );
  form.setDestination(FormApp.DestinationType.SPREADSHEET, spreadsheetId);

  form.addSectionHeaderItem()
    .setTitle('Franchise Details')
    .setHelpText('Owner and representative information');

  form.addTextItem().setTitle('Franchise Name').setRequired(true);
  form.addTextItem().setTitle('Owner / Representative Name').setRequired(true);

  form.addTextItem().setTitle('Mobile Number').setRequired(true)
    .setValidation(FormApp.createTextValidation()
      .requireTextMatchesPattern('^[0-9]{10}$')
      .setHelpText('Enter a valid 10-digit mobile number.')
      .build());

  form.addTextItem().setTitle('WhatsApp Number (optional)');

  form.addTextItem().setTitle('Email (optional)')
    .setValidation(FormApp.createTextValidation().requireTextIsEmail().build());

  form.addTextItem().setTitle('District / City').setRequired(true);
  form.addParagraphTextItem().setTitle('Full Address').setRequired(true);

  form.addMultipleChoiceItem()
    .setTitle('ID Proof Type')
    .setChoiceValues(['Aadhaar', 'Driving Licence', 'Voter ID', 'Passport', 'Bank Passbook'])
    .setRequired(true);

  form.addTextItem().setTitle('ID Proof Number').setRequired(true);
  form.addParagraphTextItem().setTitle('Cricket / Team Management Experience (optional)');

  form.addSectionHeaderItem()
    .setTitle('ID Proof Uploads')
    .setHelpText(
      'MANUAL SETUP NEEDED: right after this header, add two "File upload" questions ' +
      '(Google requires these to be added by hand in the Forms editor — see the comment ' +
      'at the top of CreateForms.gs for exact settings): ' +
      '"ID Proof — Front" (required, Images + PDF, max 1 file), ' +
      '"ID Proof — Back" (required, Images + PDF, max 1 file).'
    );

  form.addCheckboxItem()
    .setTitle('Declaration')
    .setChoiceValues([
      'I confirm that the information provided is true and I agree to follow the rules and ' +
      'regulations of Krantiveer Cricket League – Banda T10.'
    ])
    .setRequired(true);

  return form;
}
